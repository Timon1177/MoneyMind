﻿using System.Windows;

namespace MoneyMind
{
  public partial class MainWindow : Window
  {
    public MainWindow()
    {
      InitializeComponent();

      // Navigate to StartPage on load
      MainFrame.Navigate(new StartPage());
    }

    private void ToggleWindowMode_Click(object sender, RoutedEventArgs e)
    {
      if (this.WindowState == WindowState.Maximized && this.WindowStyle == WindowStyle.None)
      {
        this.WindowStyle = WindowStyle.SingleBorderWindow;
        this.WindowState = WindowState.Normal;
        FullscreenToggleButton.Content = "🗗";
      }
      else
      {
        this.WindowStyle = WindowStyle.None;
        this.WindowState = WindowState.Maximized;
        FullscreenToggleButton.Content = "⤢";
      }
    }
  }
}
