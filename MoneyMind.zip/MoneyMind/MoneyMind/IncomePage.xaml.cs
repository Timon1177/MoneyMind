﻿using System.Windows.Controls;

namespace MoneyMind
{
  public partial class IncomePage : Page
  {
    public IncomePage()
    {
      InitializeComponent();
    }
  }
}
