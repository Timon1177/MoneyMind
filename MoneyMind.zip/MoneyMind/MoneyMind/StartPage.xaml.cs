﻿using System.Windows;
using System.Windows.Controls;

namespace MoneyMind
{
  public partial class StartPage : Page
  {
    public StartPage()
    {
      InitializeComponent();

      decimal currentBalance = GetCurrentBalance();
      SaldoText.Text = $"CHF {currentBalance:N2}";
    }

    private void OpenTracking_Click(object sender, RoutedEventArgs e)
    {
      NavigationService?.Navigate(new IncomePage());
    }

    private void OpenGoals_Click(object sender, RoutedEventArgs e)
    {
      MessageBox.Show("Navigating to Savings Goals...");
    }

    private void OpenUser_Click(object sender, RoutedEventArgs e)
    {
      MessageBox.Show("Navigating to User Management...");
    }

    private decimal GetCurrentBalance()
    {
      // Hier später von Datenbank abfragen
      return 3250.00m;
    }
  }
}
